# 🎯 InterviewReady AI

> **Adaptive Technical Interview Coach powered by NVIDIA Nemotron via Nebius Token Factory & FastAPI.**

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110%2B-009688.svg)](https://fastapi.tiangolo.com/)
[![NVIDIA Nemotron](https://img.shields.io/badge/NVIDIA-Nemotron--3--Super--120B-76B900.svg)](https://developer.nvidia.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 💡 Overview

**InterviewReady AI** is an intelligent, adaptive technical interview practice platform. Built with a decoupled **FastAPI** backend and an intuitive **HTML5/CSS3/JavaScript** frontend, it simulates rigorous real-world technical interviews:

1. **📄 Resume-Aware Questions**: Upload a PDF resume to extract skills, frameworks, and projects for personalized questioning.
2. **🔄 Dynamic Adaptive Follow-ups**: Evaluates each candidate response in real-time and adapts subsequent question difficulty and depth based on prior answers.
3. **📊 Transparent 4-Part Rubric Scoring**: Scores responses across technical correctness (0-4), conceptual understanding (0-3), completeness (0-2), and communication clarity (0-1).
4. **📅 Evidence-Based 7-Day Study Plan**: Generates a tailored 7-day preparation schedule targeting the candidate's exact knowledge gaps, complete with hands-on practice tasks and follow-up review questions.
5. **📜 Local Session History**: Persists interview sessions and transcripts to a local SQLite database for retrospective tracking.
6. **⚡ Zero-Config Demo Mode**: Reviewers and evaluators can immediately test the full interview workflow without needing funded cloud API credentials.

---

## 🎬 Live Demo & Preview

![InterviewReady AI Walkthrough Demo](demo_media/demo_walkthrough.gif)

### Key Walkthrough Screenshots

| 1. Role Setup & Resume Parsing | 2. Live Adaptive Technical Question |
|:---:|:---:|
| ![Interview Setup](demo_media/01_interview_setup.png) | ![Active Interview](demo_media/02_active_question.png) |

| 3. Transparent 4-Part Rubrics | 4. Evidence-Based 7-Day Study Plan |
|:---:|:---:|
| ![Rubric Evaluation](demo_media/04_rubric_evaluation.png) | ![Study Plan Roadmap](demo_media/05_7day_study_plan.png) |

📹 **Full High-Definition Video Walkthrough:** [`demo_media/demo_walkthrough_video.webm`](demo_media/demo_walkthrough_video.webm)

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Modern Web Frontend                      │
│            (HTML5 / Responsive CSS / JavaScript)            │
└──────────────────────────────▲──────────────────────────────┘
                               │ REST API (JSON / FormData)
┌──────────────────────────────▼──────────────────────────────┐
│                    FastAPI Backend (server.py)              │
│  - /api/start     : Generate opening question               │
│  - /api/answer    : Evaluate answer & adaptive follow-up    │
│  - /api/resume    : PDF extraction (PyMuPDF / pypdf)        │
│  - /api/sessions  : SQLite history archiving                │
└──────────────────────────────▲──────────────────────────────┘
                               │
            ┌──────────────────┴──────────────────┐
            ▼                                     ▼
┌──────────────────────────────┐       ┌───────────────────────┐
│     Nebius Token Factory     │       │    Local SQLite DB    │
│   (NVIDIA Nemotron Model)    │       │    (interviews.db)    │
└──────────────────────────────┘       └───────────────────────┘
```

---

## 🚀 Quickstart Guide

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/InterviewReadyAI.git
cd InterviewReadyAI/InterviewReadyAI
```

### 2. Create and Activate Virtual Environment
**Windows (PowerShell):**
```powershell
python -m venv venv
.\venv\Scripts\activate
```

**macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure Environment
Copy `.env.example` to `.env`:
```bash
copy .env.example .env     # Windows
cp .env.example .env       # macOS / Linux
```

Edit `.env` with your preferred provider:

#### Option A: NVIDIA Nemotron on Nebius Token Factory (Default)
```env
NEBIUS_API_KEY=your_token_factory_key
NEBIUS_BASE_URL=https://api.tokenfactory.nebius.com/v1/
NEBIUS_MODEL=nvidia/nemotron-3-super-120b-a12b
DEMO_MODE=false
```

#### Option B: Zero-Config Demo Mode (Immediate Practice)
```env
DEMO_MODE=true
```

### 5. Launch the Web Application
```bash
python server.py
```
Open **[http://127.0.0.1:8000](http://127.0.0.1:8000)** in your browser.

*(Optional)* If you prefer the legacy Streamlit interface:
```bash
streamlit run app.py
```

---

## 📡 REST API Reference

| Endpoint | Method | Description |
|---|---|---|
| `/` | `GET` | Serves the single-page application (`index.html`) |
| `/api/status` | `GET` | Checks AI provider configuration and readiness |
| `/api/resume` | `POST` | Uploads and extracts text from PDF resumes |
| `/api/start` | `POST` | Generates role- and difficulty-tailored opening question |
| `/api/answer` | `POST` | Evaluates answer, scores rubric, and returns next question or final study plan |
| `/api/sessions` | `GET` | Lists previous completed interview sessions |
| `/api/sessions/{id}` | `GET` | Retrieves full transcript and study plan for a session |
| `/api/configure` | `POST` | Updates runtime credentials and `.env` securely |
| `/api/reset-demo` | `POST` | Toggles instant simulation mode without credentials |

---

## 📁 Repository Structure

```
InterviewReadyAI/
├── server.py              # Main FastAPI application & REST endpoints
├── index.html             # Responsive HTML5/CSS3/JavaScript frontend
├── app.py                 # Streamlit alternative interface
├── requirements.txt       # Project Python dependencies
├── .env.example           # Environment template (Nebius / Nemotron)
├── .gitignore             # Git exclusion rules (keys, caches, DBs)
├── LICENSE                # MIT License
├── database/
│   ├── __init__.py
│   └── db.py              # SQLite session persistence
└── modules/
    ├── __init__.py
    ├── ai_engine.py       # Nebius / OpenAI client & demo engine
    ├── interviewer.py     # Question generation & adaptive prompt logic
    ├── evaluator.py       # 4-factor rubric evaluation logic
    ├── study_planner.py   # 7-day actionable roadmap generator
    └── resume_parser.py   # PDF text extraction with pypdf fallback
```

---

## 🔒 Security & Privacy

- **No Key Leaks**: `.env` and SQLite databases are excluded by default in `.gitignore`.
- **Zero Third-Party Frontend Tracking**: Fonts and scripts are loaded securely via CDN.
- **Local Persistence**: User interview history remains strictly on your local SQLite instance.

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
