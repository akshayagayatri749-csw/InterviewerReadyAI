from modules.ai_engine import ask_ai

def make_study_plan(role, history):
    evidence = ""
    for i, item in enumerate(history, 1):
        evidence += (
            f"\n{i}. Question: {item['question']}\n"
            f"Answer: {item['answer']}\n"
            f"Evaluation: {item['evaluation']}\n"
        )
    prompt = f"""
Create a practical 7-day interview improvement plan for a student preparing for {role}.
Base it only on the interview evidence below. Prioritize repeated gaps and incorrect concepts.
Interview evidence:
{evidence}

Return Markdown with:
- Overall strengths
- Top 3 improvement areas
- A 7-day table with topic, practice task and measurable completion goal
- 5 follow-up practice questions
Do not invent facts about the student.
"""
    return ask_ai([{"role": "user", "content": prompt}])
