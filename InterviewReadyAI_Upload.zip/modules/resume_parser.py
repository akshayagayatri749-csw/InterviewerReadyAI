import io

def extract_resume(uploaded_file, max_chars=12000):
    """
    Extracts selectable plain text from an uploaded PDF.
    Supports file-like objects (Streamlit / FastAPI UploadFile) or raw bytes.
    Uses PyMuPDF with automatic fallback to pure-python pypdf.
    """
    if hasattr(uploaded_file, "getvalue"):
        data = uploaded_file.getvalue()
    elif hasattr(uploaded_file, "read"):
        data = uploaded_file.read()
    elif isinstance(uploaded_file, bytes):
        data = uploaded_file
    else:
        raise ValueError("Unsupported file type for resume extraction.")

    # Attempt 1: PyMuPDF
    try:
        import fitz
        doc = fitz.open(stream=data, filetype="pdf")
        text = "\n".join(page.get_text() for page in doc).strip()
        if text:
            return text[:max_chars]
    except Exception:
        pass

    # Attempt 2: pypdf fallback (pure Python, zero C-extension dependencies)
    try:
        import pypdf
        reader = pypdf.PdfReader(io.BytesIO(data))
        pages_text = [page.extract_text() or "" for page in reader.pages]
        text = "\n".join(pages_text).strip()
        if text:
            return text[:max_chars]
    except Exception as exc:
        raise ValueError(f"Could not parse PDF: {exc}")

    raise ValueError("No selectable text found. Try a text-based PDF rather than a scanned image.")
