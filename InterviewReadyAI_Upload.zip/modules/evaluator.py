from modules.ai_engine import ask_ai

def evaluate_answer(question, answer, role, level):
    prompt = f"""
You are a fair technical interview evaluator.
Role: {role}
Difficulty: {level}
Question: {question}
Candidate answer: {answer}

Evaluate only the answer evidence. Do not infer confidence, personality, or employability.
Use this rubric:
- Technical correctness: 0 to 4
- Conceptual understanding: 0 to 3
- Completeness: 0 to 2
- Clarity: 0 to 1

Return:
1. Total score out of 10 and the four rubric sub-scores.
2. What the candidate got right.
3. Missing or incorrect concepts.
4. A concise improved answer.
5. One useful topic to revise.

Be constructive and do not reward length alone. If the answer is uncertain, say so.
"""
    return ask_ai([{"role": "user", "content": prompt}])
