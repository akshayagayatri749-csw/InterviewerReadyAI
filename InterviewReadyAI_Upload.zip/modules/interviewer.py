from modules.ai_engine import ask_ai

def first_question(role, level, resume_text):
    resume_context = resume_text if resume_text else "No resume was provided."
    prompt = f"""
You are the interviewer in a realistic technical interview.
Target role: {role}
Difficulty: {level}
Resume context:
{resume_context}

Ask exactly ONE clear, role-relevant opening technical question.
If a resume is available, connect the question to a skill or project in it.
Do not provide the answer or evaluation. Return only the question.
"""
    return ask_ai([{"role": "user", "content": prompt}])

def next_question(role, level, history, resume_text):
    transcript = ""
    for idx, item in enumerate(history, 1):
        transcript += (
            f"\nQuestion {idx}: {item['question']}\n"
            f"Candidate answer: {item['answer']}\n"
            f"Evaluation: {item['evaluation']}\n"
        )
    prompt = f"""
Continue a technical interview for {role}, difficulty {level}.
Resume context: {resume_text or "Not provided."}
Previous interview:
{transcript}

Ask exactly ONE next question. Adapt it to the candidate's demonstrated knowledge.
If the last answer had a misconception, ask a concise follow-up that checks understanding.
Otherwise move to a related but different important skill. Avoid repeating questions.
Return only the question, without its answer.
"""
    return ask_ai([{"role": "user", "content": prompt}])
