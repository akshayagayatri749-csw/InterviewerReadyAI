import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

class AIError(Exception):
    pass

def generate_demo_response(prompt: str) -> str:
    prompt_lower = prompt.lower()
    
    # 1. 7-Day Study Plan detection
    if "7-day" in prompt_lower or "study plan" in prompt_lower or "roadmap" in prompt_lower:
        role_label = "Software Development"
        if "java" in prompt_lower:
            role_label = "Java Developer"
        elif "python" in prompt_lower:
            role_label = "Python Developer"
        elif "data analyst" in prompt_lower:
            role_label = "Data Analyst"
        elif "ai" in prompt_lower or "ml" in prompt_lower:
            role_label = "AI/ML Engineer"

        return f"""# 7-Day Technical Improvement Roadmap for {role_label}

### Overall Strengths
- Demonstrated solid familiarity with primary language concepts and standard workflows.
- Clear technical reasoning and methodical problem-solving structure.

### Top 3 Improvement Areas
1. **Edge-case resilience**: Address boundary conditions, exception hierarchies, and failure handling.
2. **System performance & concurrency**: Deepen understanding of thread synchronization, memory locking, and I/O bottlenecks.
3. **Architecture trade-offs**: Articulate design decisions around caching, distributed transactions, and database indexing.

### 7-Day Preparation Schedule

| Day | Topic Focus | Hands-on Practice Task | Measurable Milestone |
|---|---|---|---|
| **Day 1** | Language Internals & Memory | Review garbage collection, heap vs. stack allocations | Diagram object lifecycle in memory |
| **Day 2** | Collections & Data Structures | Implement custom HashMap collision resolution & Tree traversal | Benchmark lookup vs. insertion overhead |
| **Day 3** | Concurrency & Multi-threading | Write thread-safe producer-consumer queue with blocking collections | Zero-deadlock concurrency test suite |
| **Day 4** | Database Optimization & SQL | Analyze query execution plans, B-Tree indexes, and ACID isolation levels | Optimize 3 complex joins on large datasets |
| **Day 5** | REST & API Architecture | Design idempotent endpoints with auth token lifecycle & error schemas | OpenAPI contract validation |
| **Day 6** | Caching & System Resilience | Implement cache-aside pattern with Redis and circuit breakers | Resilience simulation under simulated network delay |
| **Day 7** | Full Timed Simulation | Practice verbal explanation of system trade-offs under timed conditions | Complete full 45-minute timed mock interview |

### 5 Recommended Follow-Up Practice Questions
1. How does the runtime manage thread memory visibility and race hazards across CPU cores?
2. When should you prefer optimistic locking over pessimistic locking in high-throughput workloads?
3. How do you design an API to ensure idempotent transaction processing during network retries?
4. What strategies do you use to diagnose and remediate a memory leak or CPU spike in production?
5. How do you structure unit and integration tests for asynchronous services with external dependencies?"""

    # 2. Rubric Evaluation detection (evaluating a candidate's answer)
    if "fair technical interview evaluator" in prompt_lower or ("use this rubric:" in prompt_lower and "what the candidate got right" in prompt_lower):
        # Extract candidate answer snippet if present
        return """### Rubric Score: 8/10
- **Technical correctness**: 3/4
- **Conceptual understanding**: 3/3
- **Completeness**: 1/2
- **Clarity**: 1/1

#### 1. What the candidate got right:
You clearly understood the foundational concepts, runtime mechanics, and primary use cases. The technical explanation was straightforward and accurate.

#### 2. Missing or incorrect concepts:
Be sure to explicitly touch upon edge cases (null safety, exception handling), performance implications under concurrent loads, and memory trade-offs.

#### 3. Concise improved answer:
A comprehensive answer first defines the primary mechanism, highlights internal data structures or locking granularity, and concludes with practical production trade-offs.

#### 4. One useful topic to revise:
Production synchronization strategies, lock contention mitigation, and latency profiling under heavy traffic."""

    # 3. Follow-up / Next Question detection
    if "prior answer" in prompt_lower or "next question" in prompt_lower or "follow-up" in prompt_lower:
        if "java" in prompt_lower:
            return "Building on your previous answer, how does the JVM Garbage Collector (such as G1 or ZGC) manage heap memory and stop-the-world pauses during high allocations?"
        elif "python" in prompt_lower:
            return "Building on your answer, how would you design an asynchronous background worker using asyncio or Celery to handle thousands of concurrent tasks without blocking the main event loop?"
        elif "data" in prompt_lower:
            return "How would you design an ETL data pipeline that can handle schema evolution and late-arriving events while ensuring idempotent database upserts?"
        else:
            return "Building on that approach, how would you scale this architecture horizontally to handle millions of requests while ensuring data consistency and low latency?"

    # 4. Opening / Technical Interview Question (Role-Specific)
    if "java" in prompt_lower:
        return "In Java, can you explain the core differences between HashMap, ConcurrentHashMap, and Hashtable? Specifically, how does ConcurrentHashMap achieve thread safety without synchronizing the entire table?"
    elif "python" in prompt_lower:
        return "In Python, can you explain the Global Interpreter Lock (GIL), how it affects CPU-bound vs. I/O-bound multi-threaded programs, and what approaches you use to achieve true parallelism?"
    elif "data analyst" in prompt_lower:
        return "Can you walk through how you analyze and optimize a slow SQL query involving window functions and multiple table joins on a dataset with millions of records?"
    elif "ai" in prompt_lower or "ml" in prompt_lower:
        return "Can you explain the trade-offs between L1/L2 regularization and Dropout in deep neural networks, and how you detect whether a model is underfitting vs. overfitting?"
    else:
        return "Could you explain the primary differences between processes and threads, specifically how memory management, context switching, and state isolation work between them?"


def ask_ai(messages, temperature=0.3):
    api_key = os.getenv("NEBIUS_API_KEY", "").strip()
    base_url = os.getenv("NEBIUS_BASE_URL", "https://api.tokenfactory.nebius.com/v1/").strip()
    model = os.getenv("NEBIUS_MODEL", "").strip()
    demo_mode = os.getenv("DEMO_MODE", "").lower() in ["true", "1", "yes"]

    # Check for placeholder or project ID mistakenly copied
    is_placeholder = not api_key or any(p in api_key.lower() for p in ["replace", "your_actual", "placeholder", "xxx", "test-token"])

    # If user accidentally entered OpenAI Project ID (proj_...) instead of secret key (sk-proj-...)
    if api_key.startswith("proj_") and not api_key.startswith("sk-"):
        raise AIError(
            "It looks like you entered an OpenAI Project ID (starts with 'proj_') instead of an actual secret API key. "
            "OpenAI secret keys start with 'sk-proj-...' or 'sk-...'. "
            "Please generate a Secret Key from https://platform.openai.com/api-keys or use Demo Mode."
        )

    # Auto-route OpenAI keys to OpenAI endpoint
    if api_key.startswith("sk-"):
        if "tokenfactory.nebius.com" in base_url or not base_url:
            base_url = "https://api.openai.com/v1"
        if not model or "nemotron" in model.lower():
            model = "gpt-4o-mini"

    if demo_mode or is_placeholder:
        # If in demo mode or without a valid key, provide realistic simulated feedback
        prompt_content = messages[-1].get("content", "") if messages else ""
        return generate_demo_response(prompt_content)

    try:
        client = OpenAI(api_key=api_key, base_url=base_url)
        result = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
        )
        content = result.choices[0].message.content
        if not content:
            raise AIError("The model returned an empty response. Please try again.")
        return content.strip()
    except AIError:
        raise
    except Exception as exc:
        err_msg = str(exc)
        if "401" in err_msg or "authenticate" in err_msg.lower():
            raise AIError(
                f"Authentication failed (Error 401). Your API key is invalid or expired for {base_url}. "
                "Check your key in the ⚙️ API Key settings, or switch to Demo Mode to test immediately."
            )
        raise AIError(
            f"AI request failed. Check your API key, endpoint, model ID, and network connection. Details: {exc}"
        ) from exc
