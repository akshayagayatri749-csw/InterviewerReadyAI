import streamlit as st
from modules.resume_parser import extract_resume
from modules.ai_engine import ask_ai, AIError
from modules.interviewer import first_question, next_question
from modules.evaluator import evaluate_answer
from modules.study_planner import make_study_plan
from database.db import init_db, save_session

st.set_page_config(page_title="InterviewReady AI", page_icon="🎯", layout="wide")
init_db()

st.title("🎯 InterviewReady AI")
st.caption("An adaptive technical interview coach powered by NVIDIA Nemotron through Nebius Token Factory.")

with st.sidebar:
    st.header("Interview setup")
    role = st.selectbox("Target role", ["Python Developer", "Java Developer", "Data Analyst", "AI/ML Engineer", "Software Developer"])
    level = st.selectbox("Difficulty", ["Beginner", "Intermediate", "Advanced"])
    num_questions = st.slider("Questions", 3, 8, 5)
    st.divider()
    st.caption("Your Nebius API key is read from the server environment. Never paste it into this app or commit it to GitHub.")

if "history" not in st.session_state:
    st.session_state.history = []
if "question" not in st.session_state:
    st.session_state.question = None
if "resume_text" not in st.session_state:
    st.session_state.resume_text = ""
if "started" not in st.session_state:
    st.session_state.started = False
if "report" not in st.session_state:
    st.session_state.report = None

st.subheader("1. Prepare your interview")
uploaded = st.file_uploader("Upload your resume (PDF, optional)", type=["pdf"])
if uploaded:
    try:
        st.session_state.resume_text = extract_resume(uploaded)
        st.success(f"Resume read successfully ({len(st.session_state.resume_text)} characters).")
    except Exception as e:
        st.error(f"Could not read this PDF: {e}")

if st.button("Start interview", type="primary", disabled=st.session_state.started):
    try:
        st.session_state.question = first_question(role, level, st.session_state.resume_text)
        st.session_state.history = []
        st.session_state.started = True
        st.session_state.report = None
        st.rerun()
    except AIError as e:
        st.error(str(e))

if st.session_state.started:
    st.divider()
    st.subheader("2. Your interview")
    st.info(f"Role: {role} · Difficulty: {level} · Question {len(st.session_state.history)+1} of {num_questions}")
    st.markdown("**Interviewer:** " + st.session_state.question)

    with st.form("answer_form", clear_on_submit=True):
        answer = st.text_area("Your answer", height=140, placeholder="Write your answer here...")
        submitted = st.form_submit_button("Submit answer", type="primary")

    if submitted:
        if not answer.strip():
            st.warning("Please enter an answer before submitting.")
        else:
            try:
                with st.spinner("Nemotron is evaluating your answer..."):
                    evaluation = evaluate_answer(st.session_state.question, answer, role, level)
                    st.session_state.history.append({
                        "question": st.session_state.question,
                        "answer": answer,
                        "evaluation": evaluation
                    })
                    if len(st.session_state.history) >= num_questions:
                        st.session_state.report = make_study_plan(role, st.session_state.history)
                        save_session(role, level, st.session_state.history, st.session_state.report)
                        st.session_state.started = False
                        st.rerun()
                    else:
                        st.session_state.question = next_question(
                            role, level, st.session_state.history, st.session_state.resume_text
                        )
                        st.rerun()
            except AIError as e:
                st.error(str(e))

if st.session_state.history:
    st.divider()
    st.subheader("Interview progress")
    for i, item in enumerate(st.session_state.history, 1):
        with st.expander(f"Question {i}: {item['question']}", expanded=False):
            st.write("**Your answer**")
            st.write(item["answer"])
            st.write("**Nemotron feedback**")
            st.write(item["evaluation"])

if st.session_state.report:
    st.divider()
    st.header("3. Your interview report")
    st.markdown(st.session_state.report)
    st.success("Interview saved locally in SQLite.")
    if st.button("Start a new interview"):
        for key in ["history", "question", "started", "report"]:
            st.session_state[key] = [] if key == "history" else (False if key == "started" else None)
        st.rerun()

st.divider()
st.caption("Practice feedback is AI-generated and is not a certified measure of employability. Review important feedback critically.")
