import os
import io
import json
import sqlite3
from typing import List, Optional
from datetime import datetime

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Path to local .env file in the application directory
ENV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
load_dotenv(ENV_FILE)

# Import existing application modules
from modules.ai_engine import AIError
from modules.interviewer import first_question, next_question
from modules.evaluator import evaluate_answer
from modules.study_planner import make_study_plan
from database.db import init_db, save_session, DB_PATH

# Initialize database
init_db()

app = FastAPI(
    title="InterviewReady AI API",
    description="Adaptive Technical Interview Practice Backend powered by NVIDIA Nemotron",
    version="2.0.0"
)

# Enable CORS for flexible frontend hosting (served or standalone)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- Pydantic Data Models ---

class HistoryItem(BaseModel):
    question: str
    answer: str
    evaluation: str


class StartInterviewRequest(BaseModel):
    role: str = Field(..., example="Python Developer")
    level: str = Field(..., example="Intermediate")
    resume_text: Optional[str] = ""
    num_questions: int = Field(default=5, ge=1, le=10)


class SubmitAnswerRequest(BaseModel):
    role: str
    level: str
    resume_text: Optional[str] = ""
    question: str
    answer: str
    history: List[HistoryItem] = []
    num_questions: int = 5


class ConfigRequest(BaseModel):
    api_key: str
    model: Optional[str] = "nvidia/nemotron-3-super-120b-a12b"
    base_url: Optional[str] = "https://api.tokenfactory.nebius.com/v1/"


# --- PDF Parser Utility with Fallback ---

def parse_pdf_bytes(file_bytes: bytes, max_chars: int = 12000) -> str:
    """Extract text from PDF bytes using PyMuPDF or pure-python pypdf fallback."""
    # Attempt 1: PyMuPDF if available and working
    try:
        import fitz
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        text = "\n".join(page.get_text() for page in doc).strip()
        if text:
            return text[:max_chars]
    except Exception:
        pass

    # Attempt 2: pypdf pure-python fallback
    try:
        import pypdf
        reader = pypdf.PdfReader(io.BytesIO(file_bytes))
        pages_text = [page.extract_text() or "" for page in reader.pages]
        text = "\n".join(pages_text).strip()
        if text:
            return text[:max_chars]
    except Exception as exc:
        raise ValueError(f"Failed to extract text from PDF: {exc}")

    raise ValueError("No selectable text found in PDF. Make sure it is a text-based PDF rather than a scanned image.")


# --- API Routes ---

@app.get("/")
def serve_index():
    """Serves the frontend single-page application."""
    index_path = os.path.join(os.path.dirname(__file__), "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return JSONResponse({"message": "InterviewReady AI API is running. index.html not found."}, status_code=200)


@app.get("/api/status")
def get_system_status():
    """Checks whether Nebius API credentials and model are configured."""
    load_dotenv(ENV_FILE, override=True)
    api_key = os.getenv("NEBIUS_API_KEY", "").strip()
    model = os.getenv("NEBIUS_MODEL", "").strip()
    base_url = os.getenv("NEBIUS_BASE_URL", "https://api.tokenfactory.nebius.com/v1/").strip()
    demo_mode = os.getenv("DEMO_MODE", "").lower() in ["true", "1", "yes"]
    
    is_placeholder = not api_key or any(p in api_key.lower() for p in ["replace", "your_actual", "placeholder", "xxx", "test-token"])
    is_project_id = api_key.startswith("proj_") and not api_key.startswith("sk-")
    
    is_configured = bool(api_key and model and not is_placeholder and not is_project_id and not demo_mode)
    
    provider_name = "NVIDIA Nemotron"
    if api_key.startswith("sk-") or "openai" in base_url.lower():
        provider_name = f"OpenAI ({model or 'gpt-4o-mini'})"
    elif is_configured:
        provider_name = f"Nemotron ({model.split('/')[-1]})"
    else:
        provider_name = "Simulation / Demo Mode"

    return {
        "configured": is_configured,
        "demo_mode": demo_mode or not is_configured,
        "is_project_id": is_project_id,
        "provider_name": provider_name,
        "model": model,
        "base_url": base_url,
        "api_key_set": bool(api_key and not is_placeholder),
        "env_path": ENV_FILE
    }


@app.post("/api/reset-demo")
def reset_to_demo():
    """Switches back to Demo / Simulation mode."""
    content = "NEBIUS_API_KEY=\nNEBIUS_BASE_URL=https://api.tokenfactory.nebius.com/v1/\nNEBIUS_MODEL=nvidia/nemotron-3-super-120b-a12b\nDEMO_MODE=true\n"
    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.write(content)
    os.environ["NEBIUS_API_KEY"] = ""
    os.environ["DEMO_MODE"] = "true"
    load_dotenv(ENV_FILE, override=True)
    return {"success": True, "message": "Switched to Demo Mode!"}


@app.post("/api/configure")
def update_config(payload: ConfigRequest):
    """Saves API credentials directly to the local .env file and updates runtime environment."""
    key = payload.api_key.strip()
    model = payload.model.strip() if payload.model else "nvidia/nemotron-3-super-120b-a12b"
    base_url = payload.base_url.strip() if payload.base_url else "https://api.tokenfactory.nebius.com/v1/"
    
    if not key:
        # If user saves empty key, enable demo mode
        return reset_to_demo()

    # Automatically adapt OpenAI keys
    if key.startswith("sk-"):
        if "tokenfactory" in base_url:
            base_url = "https://api.openai.com/v1"
        if not model or "nemotron" in model.lower():
            model = "gpt-4o-mini"
    
    content = f"NEBIUS_API_KEY={key}\nNEBIUS_BASE_URL={base_url}\nNEBIUS_MODEL={model}\nDEMO_MODE=false\n"
    
    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.write(content)
        
    os.environ["NEBIUS_API_KEY"] = key
    os.environ["NEBIUS_BASE_URL"] = base_url
    os.environ["NEBIUS_MODEL"] = model
    os.environ["DEMO_MODE"] = "false"
    load_dotenv(ENV_FILE, override=True)
    
    return {
        "success": True,
        "message": ".env file updated successfully!",
        "model": model,
        "base_url": base_url
    }


@app.post("/api/resume")
async def upload_resume(file: UploadFile = File(...)):
    """Uploads and parses a PDF resume into selectable plain text."""
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")
    
    try:
        content = await file.read()
        if len(content) == 0:
            raise HTTPException(status_code=400, detail="Uploaded file is empty.")
        
        extracted_text = parse_pdf_bytes(content)
        return {
            "filename": file.filename,
            "char_count": len(extracted_text),
            "text": extracted_text
        }
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Error reading PDF: {exc}")


@app.post("/api/start")
def start_interview(payload: StartInterviewRequest):
    """Generates the opening question for the interview."""
    try:
        question = first_question(payload.role, payload.level, payload.resume_text or "")
        return {
            "question": question,
            "question_number": 1,
            "total_questions": payload.num_questions
        }
    except AIError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {exc}")


@app.post("/api/answer")
def submit_answer(payload: SubmitAnswerRequest):
    """Evaluates the candidate's answer and either proceeds to the next question or completes the interview."""
    if not payload.answer.strip():
        raise HTTPException(status_code=400, detail="Answer cannot be blank.")
    
    try:
        # Step 1: Evaluate candidate's answer
        evaluation = evaluate_answer(
            question=payload.question,
            answer=payload.answer,
            role=payload.role,
            level=payload.level
        )
        
        # Step 2: Record in history
        history_list = [item.dict() for item in payload.history]
        history_list.append({
            "question": payload.question,
            "answer": payload.answer,
            "evaluation": evaluation
        })
        
        # Step 3: Check if target question count reached
        if len(history_list) >= payload.num_questions:
            report = make_study_plan(payload.role, history_list)
            save_session(payload.role, payload.level, history_list, report)
            return {
                "evaluation": evaluation,
                "history": history_list,
                "is_finished": True,
                "report": report
            }
        
        # Step 4: Generate adaptive next question
        next_q = next_question(
            role=payload.role,
            level=payload.level,
            history=history_list,
            resume_text=payload.resume_text or ""
        )
        
        return {
            "evaluation": evaluation,
            "history": history_list,
            "is_finished": False,
            "next_question": next_q,
            "question_number": len(history_list) + 1,
            "total_questions": payload.num_questions
        }
        
    except AIError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {exc}")


@app.get("/api/sessions")
def list_sessions():
    """Returns past interview sessions from the SQLite database."""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT id, created_at, role, difficulty, history_json, report FROM sessions ORDER BY id DESC LIMIT 20")
            rows = cursor.fetchall()
            
            sessions = []
            for row in rows:
                sessions.append({
                    "id": row["id"],
                    "created_at": row["created_at"],
                    "role": row["role"],
                    "difficulty": row["difficulty"],
                    "question_count": len(json.loads(row["history_json"])),
                    "report_preview": row["report"][:200] + "..." if len(row["report"]) > 200 else row["report"]
                })
            return {"sessions": sessions}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to fetch session history: {exc}")


@app.get("/api/sessions/{session_id}")
def get_session_detail(session_id: int):
    """Returns details and full study plan of a previous session."""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT id, created_at, role, difficulty, history_json, report FROM sessions WHERE id = ?", (session_id,))
            row = cursor.fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="Session not found.")
            
            return {
                "id": row["id"],
                "created_at": row["created_at"],
                "role": row["role"],
                "difficulty": row["difficulty"],
                "history": json.loads(row["history_json"]),
                "report": row["report"]
            }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Error retrieving session: {exc}")


if __name__ == "__main__":
    import uvicorn
    print("\n🚀 Starting InterviewReady AI Backend at http://127.0.0.1:8000 ...\n")
    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=True)
