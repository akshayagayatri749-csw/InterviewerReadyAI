@echo off
title InterviewReady AI Server
echo ========================================================
echo Starting InterviewReady AI Web Application...
echo ========================================================
echo.
echo Opening http://127.0.0.1:8000 in your browser...
start http://127.0.0.1:8000
echo.
"%~dp0..\venv\Scripts\python.exe" -m uvicorn server:app --app-dir "%~dp0." --host 127.0.0.1 --port 8000
pause
